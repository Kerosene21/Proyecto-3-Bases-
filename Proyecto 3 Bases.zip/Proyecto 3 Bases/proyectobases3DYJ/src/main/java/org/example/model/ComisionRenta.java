package org.example.model;

/**
 * ComisionRenta: representa la tabla comision_renta.
 */
public class ComisionRenta {
    private int id;
    private int comisionId;      // FK → comision(id)
    private int rentaId;         // FK → renta(id)
    private int numInquilinos;   // cuántos inquilinos generaron la comisión

    public ComisionRenta() { }

    public ComisionRenta(int id, int comisionId, int rentaId, int numInquilinos) {
        this.id = id;
        this.comisionId = comisionId;
        this.rentaId = rentaId;
        this.numInquilinos = numInquilinos;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getComisionId() { return comisionId; }
    public void setComisionId(int comisionId) { this.comisionId = comisionId; }

    public int getRentaId() { return rentaId; }
    public void setRentaId(int rentaId) { this.rentaId = rentaId; }

    public int getNumInquilinos() { return numInquilinos; }
    public void setNumInquilinos(int numInquilinos) { this.numInquilinos = numInquilinos; }
}
