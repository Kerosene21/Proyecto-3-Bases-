package org.example.model;

import java.sql.Date;

/**
 * Renta: representa la tabla renta.
 */
public class Renta {
    private int id;
    private int clienteId;     // FK → usuario(id)
    private int duenoId;       // FK → usuario(id)
    private int propiedadId;   // FK → propiedad(id)
    private Date fecha;        // fecha de la renta
    private double vei;        // Valor Estipulado del Inmueble
    private double vtr;        // Valor Total Renta (con comisiones)
    private double ti;         // Total Impuestos
    private double vtp;        // Valor Total a Pagar (VTR + TI)
    private String estadoRenta;// "Pendiente", "Pagado", etc.

    public Renta() { }

    public Renta(int id, int clienteId, int duenoId, int propiedadId,
                 Date fecha, double vei, double vtr, double ti,
                 double vtp, String estadoRenta) {
        this.id = id;
        this.clienteId = clienteId;
        this.duenoId = duenoId;
        this.propiedadId = propiedadId;
        this.fecha = fecha;
        this.vei = vei;
        this.vtr = vtr;
        this.ti = ti;
        this.vtp = vtp;
        this.estadoRenta = estadoRenta;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }

    public int getDuenoId() { return duenoId; }
    public void setDuenoId(int duenoId) { this.duenoId = duenoId; }

    public int getPropiedadId() { return propiedadId; }
    public void setPropiedadId(int propiedadId) { this.propiedadId = propiedadId; }

    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }

    public double getVei() { return vei; }
    public void setVei(double vei) { this.vei = vei; }

    public double getVtr() { return vtr; }
    public void setVtr(double vtr) { this.vtr = vtr; }

    public double getTi() { return ti; }
    public void setTi(double ti) { this.ti = ti; }

    public double getVtp() { return vtp; }
    public void setVtp(double vtp) { this.vtp = vtp; }

    public String getEstadoRenta() { return estadoRenta; }
    public void setEstadoRenta(String estadoRenta) { this.estadoRenta = estadoRenta; }
}
