package org.example.model;

/**
 * Impuesto: representa la tabla impuesto.
 */
public class Impuesto {
    private int id;
    private String tipoImpuesto;  // ej. "ReteFuente", "IVA"
    private double porcentaje;    // ej. 7.00 para 7%

    public Impuesto() { }

    public Impuesto(int id, String tipoImpuesto, double porcentaje) {
        this.id = id;
        this.tipoImpuesto = tipoImpuesto;
        this.porcentaje = porcentaje;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTipoImpuesto() { return tipoImpuesto; }
    public void setTipoImpuesto(String tipoImpuesto) { this.tipoImpuesto = tipoImpuesto; }

    public double getPorcentaje() { return porcentaje; }
    public void setPorcentaje(double porcentaje) { this.porcentaje = porcentaje; }
}
