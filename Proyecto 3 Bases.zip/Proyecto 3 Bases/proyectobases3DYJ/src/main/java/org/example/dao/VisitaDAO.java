package org.example.dao;

import org.example.model.Visita;
import org.example.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * VisitaDAO: operaciones CRUD sobre la tabla visita.
 */
public class VisitaDAO {

    /**
     * Inserta una nueva Visita (añadir a lista de visitas).
     */
    public void insertarVisita(Visita v) throws SQLException {
        String sql = """
                INSERT INTO visita (cliente_id, propiedad_id, fecha)
                VALUES (?, ?, CURRENT_TIMESTAMP);
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, v.getClienteId());
            ps.setInt(2, v.getPropiedadId());
            ps.executeUpdate();
        }
    }

    /**
     * Obtiene todas las visitas (propiedades) de un cliente.
     */
    public List<Visita> obtenerVisitasPorCliente(int clienteId) throws SQLException {
        String sql = """
                SELECT id, cliente_id, propiedad_id, fecha
                FROM visita
                WHERE cliente_id = ?
                ORDER BY fecha;
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, clienteId);
            ResultSet rs = ps.executeQuery();
            List<Visita> lista = new ArrayList<>();
            while (rs.next()) {
                Visita v = new Visita(
                        rs.getInt("id"),
                        rs.getInt("cliente_id"),
                        rs.getInt("propiedad_id"),
                        rs.getTimestamp("fecha")
                );
                lista.add(v);
            }
            return lista;
        }
    }
}
