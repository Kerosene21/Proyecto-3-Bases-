package org.example.model;

/**
 * Inquilino: representa la tabla inquilino.
 */
public class Inquilino {
    private int id;
    private int rentaId;          // FK → renta(id)
    private String identificacion;// cédula o documento
    private String nombre;        // nombre del inquilino

    public Inquilino() { }

    public Inquilino(int id, int rentaId, String identificacion, String nombre) {
        this.id = id;
        this.rentaId = rentaId;
        this.identificacion = identificacion;
        this.nombre = nombre;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getRentaId() { return rentaId; }
    public void setRentaId(int rentaId) { this.rentaId = rentaId; }

    public String getIdentificacion() { return identificacion; }
    public void setIdentificacion(String identificacion) { this.identificacion = identificacion; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
}
