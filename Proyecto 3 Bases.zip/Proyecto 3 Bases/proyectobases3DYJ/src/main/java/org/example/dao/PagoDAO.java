package org.example.dao;

import org.example.model.Pago;
import org.example.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PagoDAO {
    private Connection conn;

    public PagoDAO() throws SQLException {
        this.conn = DBConnection.getInstance();
    }

    /**
     * Inserta un pago en efectivo para una renta.
     */
    public int insertarPagoEfectivo(int rentaId, double monto) throws SQLException {
        String sql = "INSERT INTO pago (renta_id, tipo_pago, valor, detalles) " +
                "VALUES (?, 'EFECTIVO', ?, NULL) RETURNING id";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            ps.setDouble(2, monto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                } else {
                    throw new SQLException("No se obtuvo ID al insertar pago");
                }
            }
        }
    }

    /**
     * Inserta un pago con tarjeta para una renta.
     * detallesTarjeta puede ser JSON o texto con número de tarjeta (en un caso real, no se guardaría en texto plano).
     */
    public int insertarPagoTarjeta(int rentaId, double monto, String detallesTarjeta) throws SQLException {
        String sql = "INSERT INTO pago (renta_id, tipo_pago, valor, detalles) " +
                "VALUES (?, 'TARJETA', ?, ?) RETURNING id";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            ps.setDouble(2, monto);
            ps.setString(3, detallesTarjeta);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                } else {
                    throw new SQLException("No se obtuvo ID al insertar pago tarjeta");
                }
            }
        }
    }

    /**
     * Inserta un pago con bono para una renta.
     * detallesBono puede contener el ID del bono o información relevante.
     */
    public int insertarPagoBono(int rentaId, double monto, String detallesBono) throws SQLException {
        String sql = "INSERT INTO pago (renta_id, tipo_pago, valor, detalles) " +
                "VALUES (?, 'BONO', ?, ?) RETURNING id";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            ps.setDouble(2, monto);
            ps.setString(3, detallesBono);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                } else {
                    throw new SQLException("No se obtuvo ID al insertar pago bono");
                }
            }
        }
    }

    /**
     * Obtiene todos los pagos asociados a una renta.
     */
    public List<Pago> obtenerPagosPorRenta(int rentaId) throws SQLException {
        String sql = "SELECT * FROM pago WHERE renta_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Pago> lista = new ArrayList<>();
                while (rs.next()) {
                    Pago p = new Pago();
                    p.setId(rs.getInt("id"));
                    p.setRentaId(rs.getInt("renta_id"));
                    p.setTipoPago(rs.getString("tipo_pago"));
                    p.setValor(rs.getDouble("valor"));
                    p.setDetalles(rs.getString("detalles"));
                    lista.add(p);
                }
                return lista;
            }
        }
    }
}
