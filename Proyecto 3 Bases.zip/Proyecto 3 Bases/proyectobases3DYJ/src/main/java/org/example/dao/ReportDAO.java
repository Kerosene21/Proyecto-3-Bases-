package org.example.dao;

import org.example.util.DBConnection;

import java.sql.Connection;
import java.sql.Date;                 // <<– usar java.sql.Date
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;           // <<– importar java.util
import java.util.LinkedHashMap;       // <<– importar java.util
import java.util.List;
import java.util.Map;

/**
 * ReportDAO: contiene todos los métodos que ejecutan las consultas de reportería.
 * Cada método devuelve un List<Map<String,Object>>, donde cada Map representa una fila (columna→valor).
 */
public class ReportDAO {

    /**
     * 1) Cantidad total de propiedades rentadas por cliente en un mes y año dados.
     *    SELECT cliente_id, COUNT(*) AS total_rentas
     *    FROM renta
     *    WHERE DATE_PART('year', fecha) = ? AND DATE_PART('month', fecha) = ?
     *    GROUP BY cliente_id;
     */
    public List<Map<String, Object>> getPropiedadesRentadasPorCliente(int year, int month) throws SQLException {
        String sql = """
                SELECT 
                    r.cliente_id AS cliente_id, 
                    COUNT(*)       AS total_rentas
                FROM renta r
                WHERE DATE_PART('year', r.fecha) = ? 
                  AND DATE_PART('month', r.fecha) = ?
                GROUP BY r.cliente_id
                ORDER BY total_rentas DESC;
                """;

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, year);
            ps.setInt(2, month);

            ResultSet rs = ps.executeQuery();
            return resultSetToList(rs);
        }
    }

    /**
     * 2) Suma total pagada a los dueños por las rentas de sus propiedades en un periodo (fecha inicio / fecha fin).
     *    SELECT dueno_id, SUM(vei) AS suma_valor_rentas
     *    FROM renta
     *    WHERE fecha BETWEEN ? AND ?
     *    GROUP BY dueno_id;
     */
    public List<Map<String, Object>> getSumaPagadaADuenoPorPeriodo(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = """
                SELECT 
                    r.dueno_id            AS dueno_id,
                    SUM(r.vei)            AS suma_valor_rentas
                FROM renta r
                WHERE r.fecha BETWEEN ? AND ?
                GROUP BY r.dueno_id
                ORDER BY suma_valor_rentas DESC;
                """;

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();
            return resultSetToList(rs);
        }
    }

    /**
     * 3) Suma y cantidad de rentas por cliente, en un periodo (fecha inicio / fecha fin).
     *    SELECT cliente_id, COUNT(*) AS cantidad_rentas, SUM(vtp) AS total_pagado
     *    FROM renta
     *    WHERE fecha BETWEEN ? AND ?
     *    GROUP BY cliente_id;
     */
    public List<Map<String, Object>> getSumaYCantidadRentasPorCliente(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = """
                SELECT 
                    r.cliente_id         AS cliente_id,
                    COUNT(*)             AS cantidad_rentas,
                    SUM(r.vtp)           AS total_pagado
                FROM renta r
                WHERE r.fecha BETWEEN ? AND ?
                GROUP BY r.cliente_id
                ORDER BY total_pagado DESC;
                """;

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();
            return resultSetToList(rs);
        }
    }

    /**
     * 4) Número total de rentas por país, departamento, municipio y ubicación (location).
     *    SELECT p.pais, p.departamento, p.municipio, p.ubicacion, COUNT(*) AS total_rentas
     *    FROM renta r
     *    JOIN propiedad p ON r.propiedad_id = p.id
     *    WHERE r.fecha BETWEEN ? AND ?
     *    GROUP BY p.pais, p.departamento, p.municipio, p.ubicacion;
     */
    public List<Map<String, Object>> getTotalRentasPorUbicacion(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = """
                SELECT 
                    p.pais          AS pais,
                    p.departamento  AS departamento,
                    p.municipio     AS municipio,
                    p.ubicacion     AS ubicacion,
                    COUNT(*)        AS total_rentas
                FROM renta r
                JOIN propiedad p ON r.propiedad_id = p.id
                WHERE r.fecha BETWEEN ? AND ?
                GROUP BY p.pais, p.departamento, p.municipio, p.ubicacion
                ORDER BY total_rentas DESC;
               """;

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();
            return resultSetToList(rs);
        }
    }

    /**
     * 5) Reporte por períodos (fecha inicio / fecha fin) de impuestos que se deben pagar por cada renta.
     *    SELECT r.id AS renta_id, r.fecha, i.tipo_impuesto, i.porcentaje
     *    FROM renta r
     *    JOIN impuesto_renta ir ON r.id = ir.renta_id
     *    JOIN impuesto i ON ir.impuesto_id = i.id
     *    WHERE r.fecha BETWEEN ? AND ?
     *    ORDER BY r.fecha;
     */
    public List<Map<String, Object>> getImpuestosPorRenta(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = """
                SELECT 
                    r.id             AS renta_id,
                    r.fecha          AS fecha,
                    i.tipo_impuesto  AS tipo_impuesto,
                    i.porcentaje     AS porcentaje
                FROM renta r
                JOIN impuesto_renta ir ON r.id = ir.renta_id
                JOIN impuesto i ON ir.impuesto_id = i.id
                WHERE r.fecha BETWEEN ? AND ?
                ORDER BY r.fecha;
                """;

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();
            return resultSetToList(rs);
        }
    }

    /**
     * 6) Tipos de propiedades más rentadas.
     *    SELECT p.tipo_propiedad, COUNT(*) AS veces
     *    FROM renta r
     *    JOIN propiedad p ON r.propiedad_id = p.id
     *    GROUP BY p.tipo_propiedad
     *    ORDER BY veces DESC;
     */
    public List<Map<String, Object>> getTiposPropiedadesMasRentadas() throws SQLException {
        String sql = """
                SELECT 
                    p.tipo_propiedad   AS tipo_propiedad,
                    COUNT(*)           AS veces
                FROM renta r
                JOIN propiedad p ON r.propiedad_id = p.id
                GROUP BY p.tipo_propiedad
                ORDER BY veces DESC;
                """;

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            return resultSetToList(rs);
        }
    }

    /**
     * 7) Totales de rentas por periodo con impuestos.
     *    SELECT DATE_PART('year', fecha) AS anio, DATE_PART('month', fecha) AS mes, SUM(vtp) AS total_con_impuestos
     *    FROM renta
     *    WHERE fecha BETWEEN ? AND ?
     *    GROUP BY anio, mes
     *    ORDER BY anio, mes;
     */
    public List<Map<String, Object>> getTotalesRentasConImpuestos(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = """
                SELECT 
                    DATE_PART('year', r.fecha)   AS anio,
                    DATE_PART('month', r.fecha)  AS mes,
                    SUM(r.vtp)                   AS total_con_impuestos
                FROM renta r
                WHERE r.fecha BETWEEN ? AND ?
                GROUP BY anio, mes
                ORDER BY anio, mes;
                """;

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();
            return resultSetToList(rs);
        }
    }

    /**
     * 8) Totales de comisiones pagadas por periodo.
     *    SELECT c.tipo_comision,
     *           SUM(r.vei * (c.porcentaje/100) * cr.num_inquilinos) AS total_comision
     *    FROM comision_renta cr
     *    JOIN comision c ON cr.comision_id = c.id
     *    JOIN renta r ON cr.renta_id = r.id
     *    WHERE r.fecha BETWEEN ? AND ?
     *    GROUP BY c.tipo_comision
     *    ORDER BY total_comision DESC;
     */
    public List<Map<String, Object>> getTotalesComisionesPorPeriodo(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = """
                SELECT
                    c.tipo_comision AS tipo_comision,
                    SUM(r.vei * (c.porcentaje / 100.0) * cr.num_inquilinos) AS total_comision
                FROM comision_renta cr
                JOIN comision c ON cr.comision_id = c.id
                JOIN renta r ON cr.renta_id = r.id
                WHERE r.fecha BETWEEN ? AND ?
                GROUP BY c.tipo_comision
                ORDER BY total_comision DESC;
                """;

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();
            return resultSetToList(rs);
        }
    }

    /**
     * Utility privado: convierte un ResultSet en un List<Map<String,Object>>.
     */
    private List<Map<String, Object>> resultSetToList(ResultSet rs) throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();

        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<>();
            for (int i = 1; i <= columnCount; i++) {
                String columnName = meta.getColumnLabel(i);
                Object value = rs.getObject(i);
                row.put(columnName, value);
            }
            rows.add(row);
        }
        return rows;
    }
}
