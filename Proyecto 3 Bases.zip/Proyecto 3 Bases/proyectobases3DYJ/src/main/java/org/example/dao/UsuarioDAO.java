package org.example.dao;

import org.example.model.Cliente;
import org.example.model.Dueno;
import org.example.model.Usuario;
import org.example.util.DBConnection;

import java.sql.*;

/**
 * UsuarioDAO: operaciones CRUD sobre la tabla usuario.
 * Soporta insertar Cliente, insertar Dueno y buscar/validar login.
 */
public class UsuarioDAO {

    /**
     * Inserta un nuevo Cliente en la BD.
     */
    public void insertarCliente(Cliente cliente) throws SQLException {
        String sql = """
                INSERT INTO usuario
                  (nombre_usuario, contrasena, nombre, apellido, correo, tipo_cuenta, renta_maxima)
                VALUES (?, ?, ?, ?, ?, 'CLIENTE', ?);
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cliente.getNombreUsuario());
            ps.setString(2, cliente.getContrasena());
            ps.setString(3, cliente.getNombre());
            ps.setString(4, cliente.getApellido());
            ps.setString(5, cliente.getCorreo());
            ps.setDouble(6, cliente.getRentaMaxima());
            ps.executeUpdate();
        }
    }

    /**
     * Inserta un nuevo Dueno en la BD.
     */
    public void insertarDueno(Dueno dueno) throws SQLException {
        String sql = """
                INSERT INTO usuario
                  (nombre_usuario, contrasena, nombre, apellido, correo, tipo_cuenta)
                VALUES (?, ?, ?, ?, ?, 'DUENO');
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, dueno.getNombreUsuario());
            ps.setString(2, dueno.getContrasena());
            ps.setString(3, dueno.getNombre());
            ps.setString(4, dueno.getApellido());
            ps.setString(5, dueno.getCorreo());
            ps.executeUpdate();
        }
    }

    /**
     * Busca un Usuario por nombreUsuario y contrasena.
     * Si lo encuentra, devuelve un objeto Usuario (Cliente o Dueno según tipo_cuenta).
     * Si no, devuelve null.
     */
    public Usuario buscarPorCredenciales(String nombreUsuario, String contrasena) throws SQLException {
        String sql = """
                SELECT id, nombre_usuario, contrasena, nombre, apellido, correo, tipo_cuenta, renta_maxima
                FROM usuario
                WHERE nombre_usuario = ? AND contrasena = ?;
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nombreUsuario);
            ps.setString(2, contrasena);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                String correo = rs.getString("correo");
                String tipo = rs.getString("tipo_cuenta");
                double rentaMax = rs.getDouble("renta_maxima");

                if ("CLIENTE".equalsIgnoreCase(tipo)) {
                    return new Cliente(id, nombreUsuario, contrasena, nombre, apellido, correo, tipo, rentaMax);
                } else {
                    return new Dueno(id, nombreUsuario, contrasena, nombre, apellido, correo, tipo);
                }
            } else {
                return null;
            }
        }
    }
}
