package org.example.model;

/**
 * Usuario: clase padre de Cliente y Dueno.
 */
public class Usuario {
    protected int id;
    protected String nombreUsuario;
    protected String contrasena;
    protected String nombre;
    protected String apellido;
    protected String correo;
    protected String tipoCuenta;   // "CLIENTE" o "DUENO"

    public Usuario() { }

    public Usuario(int id, String nombreUsuario, String contrasena,
                   String nombre, String apellido, String correo, String tipoCuenta) {
        this.id = id;
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.tipoCuenta = tipoCuenta;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getTipoCuenta() { return tipoCuenta; }
    public void setTipoCuenta(String tipoCuenta) { this.tipoCuenta = tipoCuenta; }
}
