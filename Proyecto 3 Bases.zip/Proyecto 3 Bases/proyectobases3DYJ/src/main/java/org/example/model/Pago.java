package org.example.model;

/**
 * Pago: representa la tabla pago.
 */
public class Pago {
    private int id;
    private int rentaId;          // FK → renta(id)
    private String tipoPago;      // ej. "EFECTIVO", "TARJETA", "BONO"
    private double valor;         // monto pagado
    private String detalles;      // detalles adicionales (JSON u otro)

    public Pago() { }

    public Pago(int id, int rentaId, String tipoPago, double valor, String detalles) {
        this.id = id;
        this.rentaId = rentaId;
        this.tipoPago = tipoPago;
        this.valor = valor;
        this.detalles = detalles;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getRentaId() { return rentaId; }
    public void setRentaId(int rentaId) { this.rentaId = rentaId; }

    public String getTipoPago() { return tipoPago; }
    public void setTipoPago(String tipoPago) { this.tipoPago = tipoPago; }

    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    public String getDetalles() { return detalles; }
    public void setDetalles(String detalles) { this.detalles = detalles; }
}
