package org.example.dao;

import org.example.model.Comision;
import org.example.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ComisionDAO {
    private Connection conn;

    public ComisionDAO() throws SQLException {
        this.conn = DBConnection.getInstance();
    }

    /**
     * Obtiene todas las comisiones vigentes (para cálculo en RentaService).
     */
    public List<Comision> obtenerComisionesVigentes() throws SQLException {
        String sql = "SELECT * FROM comision";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            List<Comision> lista = new ArrayList<>();
            while (rs.next()) {
                Comision c = new Comision();
                c.setId(rs.getInt("id"));
                c.setTipoComision(rs.getString("tipo_comision"));
                c.setPorcentaje(rs.getDouble("porcentaje"));
                lista.add(c);
            }
            return lista;
        }
    }

    /**
     * Inserta un servicio adicional (comisión) asociado a una renta.
     * Aquí, "idServicio" es en realidad el ID de comision, y numInquilinos para ese servicio.
     */
    public void insertarServicioAdicional(int rentaId, int idServicio, int numInquilinos) throws SQLException {
        String sql = "INSERT INTO comision_renta (comision_id, renta_id, num_inquilinos) VALUES (?, ?, ?)";
        // Nota: Debes tener creada la tabla comision_renta que relacione comision y renta
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idServicio);
            ps.setInt(2, rentaId);
            ps.setInt(3, numInquilinos);
            ps.executeUpdate();
        }
    }

    // Si necesitas obtener comisiones por renta:
    public List<Comision> obtenerComisionesPorRenta(int rentaId) throws SQLException {
        String sql = "SELECT c.id, c.tipo_comision, c.porcentaje " +
                "FROM comision c " +
                "JOIN comision_renta cr ON c.id = cr.comision_id " +
                "WHERE cr.renta_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Comision> lista = new ArrayList<>();
                while (rs.next()) {
                    Comision c = new Comision();
                    c.setId(rs.getInt("id"));
                    c.setTipoComision(rs.getString("tipo_comision"));
                    c.setPorcentaje(rs.getDouble("porcentaje"));
                    lista.add(c);
                }
                return lista;
            }
        }
    }
}
