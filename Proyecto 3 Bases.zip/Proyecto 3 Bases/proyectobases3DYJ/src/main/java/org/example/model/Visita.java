package org.example.model;

import java.sql.Timestamp;

public class Visita {
    private int id;
    private int clienteId;        // FK → usuario(id) de tipo CLIENTE
    private int propiedadId;      // FK → propiedad(id)
    private Timestamp fecha;      // Timestamp de la visita

    public Visita() { }

    public Visita(int id, int clienteId, int propiedadId, Timestamp fecha) {
        this.id = id;
        this.clienteId = clienteId;
        this.propiedadId = propiedadId;
        this.fecha = fecha;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }

    public int getPropiedadId() { return propiedadId; }
    public void setPropiedadId(int propiedadId) { this.propiedadId = propiedadId; }

    public Timestamp getFecha() { return fecha; }
    public void setFecha(Timestamp fecha) { this.fecha = fecha; }
}
