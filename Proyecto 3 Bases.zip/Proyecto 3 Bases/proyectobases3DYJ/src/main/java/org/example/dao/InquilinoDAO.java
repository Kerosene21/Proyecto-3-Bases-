package org.example.dao;

import org.example.model.Inquilino;
import org.example.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InquilinoDAO {
    private Connection conn;

    public InquilinoDAO() throws SQLException {
        this.conn = DBConnection.getInstance();
    }

    /**
     * Inserta un inquilino para una renta dada.
     */
    public void insertarInquilino(int rentaId, String identificacion, String nombre) throws SQLException {
        String sql = "INSERT INTO inquilino (renta_id, identificacion, nombre) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            ps.setString(2, identificacion);
            ps.setString(3, nombre);
            ps.executeUpdate();
        }
    }

    /**
     * Obtiene todos los inquilinos asociados a una renta.
     */
    public List<Inquilino> obtenerInquilinosPorRenta(int rentaId) throws SQLException {
        String sql = "SELECT * FROM inquilino WHERE renta_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Inquilino> lista = new ArrayList<>();
                while (rs.next()) {
                    Inquilino i = new Inquilino();
                    i.setId(rs.getInt("id"));
                    i.setRentaId(rs.getInt("renta_id"));
                    i.setIdentificacion(rs.getString("identificacion"));
                    i.setNombre(rs.getString("nombre"));
                    lista.add(i);
                }
                return lista;
            }
        }
    }
}
