package org.example.dao;

import org.example.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * ReporteDAO.java
 * Contiene métodos genéricos para ejecutar las consultas parametrizadas que produce los reportes.
 */
public class ReporteDAO {
    private Connection conn;

    public ReporteDAO() throws SQLException {
        this.conn = DBConnection.getInstance();
    }

    /**
     * Cantidad total de propiedades rentadas por cliente por mes/año.
     * Parámetros: idCliente, fechaInicio, fechaFin.
     * Retorna lista de arreglos de objetos: [periodo (String), totalRentadas (int)].
     */
    public List<Object[]> totalPropiedadesRentasPorCliente(int idCliente, Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = "SELECT TO_CHAR(fecha, 'YYYY-MM') AS periodo, " +
                "COUNT(propiedad_id) AS total_rentas " +
                "FROM renta " +
                "WHERE cliente_id = ? AND fecha BETWEEN ? AND ? " +
                "GROUP BY TO_CHAR(fecha, 'YYYY-MM') " +
                "ORDER BY periodo DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            ps.setDate(2, fechaInicio);
            ps.setDate(3, fechaFin);
            try (ResultSet rs = ps.executeQuery()) {
                List<Object[]> lista = new ArrayList<>();
                while (rs.next()) {
                    String periodo = rs.getString("periodo");
                    int total = rs.getInt("total_rentas");
                    lista.add(new Object[]{periodo, total});
                }
                return lista;
            }
        }
    }

    /**
     * Suma total pagada a dueños por rentas en un período.
     * Parámetros: idDueno, fechaInicio, fechaFin.
     * Retorna lista: [periodo (String), sumaVEI (double)].
     */
    public List<Object[]> sumaPagadaADueno(int idDueno, Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = "SELECT TO_CHAR(fecha, 'YYYY-MM') AS periodo, " +
                "SUM(vei) AS suma_vei " +
                "FROM renta " +
                "WHERE dueno_id = ? AND fecha BETWEEN ? AND ? " +
                "GROUP BY TO_CHAR(fecha, 'YYYY-MM') " +
                "ORDER BY periodo DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idDueno);
            ps.setDate(2, fechaInicio);
            ps.setDate(3, fechaFin);
            try (ResultSet rs = ps.executeQuery()) {
                List<Object[]> lista = new ArrayList<>();
                while (rs.next()) {
                    String periodo = rs.getString("periodo");
                    double suma = rs.getDouble("suma_vei");
                    lista.add(new Object[]{periodo, suma});
                }
                return lista;
            }
        }
    }

    /**
     * Suma y cantidad de rentas por cliente en un período.
     * Parámetros: idCliente, fechaInicio, fechaFin.
     * Retorna lista: [periodo (String), sumaVEI (double), cantidadRentas (int)].
     */
    public List<Object[]> sumaYCantidadRentasPorCliente(int idCliente, Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = "SELECT TO_CHAR(fecha, 'YYYY-MM') AS periodo, " +
                "SUM(vei) AS suma_vei, COUNT(*) AS cantidad_rentas " +
                "FROM renta " +
                "WHERE cliente_id = ? AND fecha BETWEEN ? AND ? " +
                "GROUP BY TO_CHAR(fecha, 'YYYY-MM') " +
                "ORDER BY periodo DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            ps.setDate(2, fechaInicio);
            ps.setDate(3, fechaFin);
            try (ResultSet rs = ps.executeQuery()) {
                List<Object[]> lista = new ArrayList<>();
                while (rs.next()) {
                    String periodo = rs.getString("periodo");
                    double suma = rs.getDouble("suma_vei");
                    int cantidad = rs.getInt("cantidad_rentas");
                    lista.add(new Object[]{periodo, suma, cantidad});
                }
                return lista;
            }
        }
    }

    /**
     * Total de rentas por país, departamento, municipio y ubicación.
     * Parámetros: pueden ser todos nulos o algunos valores.
     * El mapa filtros puede contener claves: "pais", "departamento", "municipio", "ubicacion".
     * Retorna lista: [pais (String), departamento (String), municipio (String), ubicacion (String), totalRentas (int)].
     */
    public List<Object[]> rentasPorUbicacion(Map<String, String> filtros) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT p.pais, p.departamento, p.municipio, p.ubicacion, COUNT(r.id) AS total_rentas " +
                        "FROM renta r " +
                        "JOIN propiedad p ON r.propiedad_id = p.id WHERE 1=1"
        );
        List<String> params = new ArrayList<>();

        if (filtros.get("pais") != null) {
            sql.append(" AND p.pais = ?");
            params.add(filtros.get("pais"));
        }
        if (filtros.get("departamento") != null) {
            sql.append(" AND p.departamento = ?");
            params.add(filtros.get("departamento"));
        }
        if (filtros.get("municipio") != null) {
            sql.append(" AND p.municipio = ?");
            params.add(filtros.get("municipio"));
        }
        if (filtros.get("ubicacion") != null) {
            sql.append(" AND p.ubicacion = ?");
            params.add(filtros.get("ubicacion"));
        }
        sql.append(" GROUP BY p.pais, p.departamento, p.municipio, p.ubicacion ORDER BY total_rentas DESC");

        try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setString(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Object[]> lista = new ArrayList<>();
                while (rs.next()) {
                    String pais = rs.getString("pais");
                    String depto = rs.getString("departamento");
                    String muni = rs.getString("municipio");
                    String ubi = rs.getString("ubicacion");
                    int total = rs.getInt("total_rentas");
                    lista.add(new Object[]{pais, depto, muni, ubi, total});
                }
                return lista;
            }
        }
    }

    /**
     * Reporte de impuestos a pagar por mes/año.
     * Parámetros: fechaInicio, fechaFin.
     * Retorna lista: [periodo (String), totalImpuestos (double)].
     */
    public List<Object[]> reporteImpuestosPorPeriodo(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = "SELECT TO_CHAR(r.fecha, 'YYYY-MM') AS periodo, " +
                "SUM((r.vei + r.vtr - r.vei) * i.porcentaje / 100) AS total_impuestos " +
                "FROM renta r " +
                "JOIN impuesto_renta ir ON r.id = ir.renta_id " +
                "JOIN impuesto i ON ir.impuesto_id = i.id " +
                "WHERE r.fecha BETWEEN ? AND ? " +
                "GROUP BY TO_CHAR(r.fecha, 'YYYY-MM') " +
                "ORDER BY periodo DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);
            try (ResultSet rs = ps.executeQuery()) {
                List<Object[]> lista = new ArrayList<>();
                while (rs.next()) {
                    String periodo = rs.getString("periodo");
                    double totalImpuestos = rs.getDouble("total_impuestos");
                    lista.add(new Object[]{periodo, totalImpuestos});
                }
                return lista;
            }
        }
    }

    /**
     * Tipos de propiedades más rentadas en un período.
     * Parámetros: fechaInicio, fechaFin. (Ubicación opcional se puede agregar)
     * Retorna lista: [tipoPropiedad (String), vecesRentada (int)].
     */
    public List<Object[]> tiposPropiedadesMasRentadas(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = "SELECT p.tipo_propiedad, COUNT(r.id) AS veces_rentada " +
                "FROM renta r " +
                "JOIN propiedad p ON r.propiedad_id = p.id " +
                "WHERE r.fecha BETWEEN ? AND ? " +
                "GROUP BY p.tipo_propiedad " +
                "ORDER BY veces_rentada DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);
            try (ResultSet rs = ps.executeQuery()) {
                List<Object[]> lista = new ArrayList<>();
                while (rs.next()) {
                    String tipo = rs.getString("tipo_propiedad");
                    int veces = rs.getInt("veces_rentada");
                    lista.add(new Object[]{tipo, veces});
                }
                return lista;
            }
        }
    }

    /**
     * Totales de rentas por período con impuestos incluidos.
     * Parámetros: fechaInicio, fechaFin.
     * Retorna lista: [periodo (String), totalConImpuestos (double)].
     */
    public List<Object[]> totalesRentasConImpuestos(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = "SELECT TO_CHAR(r.fecha, 'YYYY-MM') AS periodo, SUM(r.vtp) AS total_con_impuestos " +
                "FROM renta r " +
                "WHERE r.fecha BETWEEN ? AND ? " +
                "GROUP BY TO_CHAR(r.fecha, 'YYYY-MM') " +
                "ORDER BY periodo DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);
            try (ResultSet rs = ps.executeQuery()) {
                List<Object[]> lista = new ArrayList<>();
                while (rs.next()) {
                    String periodo = rs.getString("periodo");
                    double totalCon = rs.getDouble("total_con_impuestos");
                    lista.add(new Object[]{periodo, totalCon});
                }
                return lista;
            }
        }
    }

    /**
     * Totales de comisiones pagadas por período.
     * Parámetros: fechaInicio, fechaFin.
     * Retorna lista: [periodo (String), totalComisiones (double)].
     */
    public List<Object[]> totalesComisionesPorPeriodo(Date fechaInicio, Date fechaFin) throws SQLException {
        String sql = "SELECT TO_CHAR(r.fecha, 'YYYY-MM') AS periodo, SUM(r.vtr - r.vei) AS total_comisiones " +
                "FROM renta r " +
                "WHERE r.fecha BETWEEN ? AND ? " +
                "GROUP BY TO_CHAR(r.fecha, 'YYYY-MM') " +
                "ORDER BY periodo DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);
            try (ResultSet rs = ps.executeQuery()) {
                List<Object[]> lista = new ArrayList<>();
                while (rs.next()) {
                    String periodo = rs.getString("periodo");
                    double totalCom = rs.getDouble("total_comisiones");
                    lista.add(new Object[]{periodo, totalCom});
                }
                return lista;
            }
        }
    }
}
