package org.example.model;

public class Propiedad {
    private int id;
    private String tipoPropiedad;   // Ej. "Casa", "Apartamento"
    private String direccion;
    private String pais;
    private String departamento;
    private String municipio;
    private String ubicacion;       // barrio o zona
    private int cuartos;
    private double renta;           // valor estipulado
    private String estado;          // "Activo", "Inactivo"
    private int duenoId;            // FK a usuario(id)

    public Propiedad() { }

    public Propiedad(int id, String tipoPropiedad, String direccion,
                     String pais, String departamento, String municipio,
                     String ubicacion, int cuartos, double renta,
                     String estado, int duenoId) {
        this.id = id;
        this.tipoPropiedad = tipoPropiedad;
        this.direccion = direccion;
        this.pais = pais;
        this.departamento = departamento;
        this.municipio = municipio;
        this.ubicacion = ubicacion;
        this.cuartos = cuartos;
        this.renta = renta;
        this.estado = estado;
        this.duenoId = duenoId;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTipoPropiedad() { return tipoPropiedad; }
    public void setTipoPropiedad(String tipoPropiedad) { this.tipoPropiedad = tipoPropiedad; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getPais() { return pais; }
    public void setPais(String pais) { this.pais = pais; }

    public String getDepartamento() { return departamento; }
    public void setDepartamento(String departamento) { this.departamento = departamento; }

    public String getMunicipio() { return municipio; }
    public void setMunicipio(String municipio) { this.municipio = municipio; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    public int getCuartos() { return cuartos; }
    public void setCuartos(int cuartos) { this.cuartos = cuartos; }

    public double getRenta() { return renta; }
    public void setRenta(double renta) { this.renta = renta; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public int getDuenoId() { return duenoId; }
    public void setDuenoId(int duenoId) { this.duenoId = duenoId; }
}
