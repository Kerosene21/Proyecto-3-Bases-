package org.example.dao;

import org.example.model.Propiedad;
import org.example.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * PropiedadDAO: operaciones CRUD sobre la tabla propiedad
 * y método de búsqueda con filtros dinámicos.
 */
public class PropiedadDAO {

    /**
     * Inserta una nueva Propiedad.
     * Devuelve el id generado.
     */
    public int insertarPropiedad(Propiedad p) throws SQLException {
        String sql = """
                INSERT INTO propiedad
                  (tipo_propiedad, direccion, pais, departamento, municipio, ubicacion, cuartos, renta, estado, dueno_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                RETURNING id;
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getTipoPropiedad());
            ps.setString(2, p.getDireccion());
            ps.setString(3, p.getPais());
            ps.setString(4, p.getDepartamento());
            ps.setString(5, p.getMunicipio());
            ps.setString(6, p.getUbicacion());
            ps.setInt(7, p.getCuartos());
            ps.setDouble(8, p.getRenta());
            ps.setString(9, p.getEstado());
            ps.setInt(10, p.getDuenoId());

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                throw new SQLException("No se pudo insertar la propiedad.");
            }
        }
    }

    /**
     * Obtiene una Propiedad por su ID.
     * Si no existe, devuelve null.
     */
    public Propiedad obtenerPorId(int id) throws SQLException {
        String sql = """
                SELECT id, tipo_propiedad, direccion, pais, departamento, municipio, ubicacion,
                       cuartos, renta, estado, dueno_id
                FROM propiedad
                WHERE id = ?;
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Propiedad(
                        rs.getInt("id"),
                        rs.getString("tipo_propiedad"),
                        rs.getString("direccion"),
                        rs.getString("pais"),
                        rs.getString("departamento"),
                        rs.getString("municipio"),
                        rs.getString("ubicacion"),
                        rs.getInt("cuartos"),
                        rs.getDouble("renta"),
                        rs.getString("estado"),
                        rs.getInt("dueno_id")
                );
            } else {
                return null;
            }
        }
    }

    /**
     * Busca propiedades según los filtros dinámicos pasados en el Map.
     * Los posibles filtros (keys) son:
     *  - "pais"         (String)
     *  - "departamento" (String)
     *  - "municipio"    (String)
     *  - "ubicacion"    (String)
     *  - "tipo"         (String)
     *  - "cuartos"      (Integer)
     *  - "rentaMin"     (Double)
     *  - "rentaMax"     (Double)
     *
     * Si el mapa está vacío, devuelve todas las propiedades.
     */
    public List<Propiedad> buscarPorFiltros(Map<String, Object> filtros) throws SQLException {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT id, tipo_propiedad, direccion, pais, departamento, municipio, ubicacion, ")
                .append("cuartos, renta, estado, dueno_id ")
                .append("FROM propiedad ");

        // Construcción dinámica de WHERE
        if (!filtros.isEmpty()) {
            sb.append("WHERE ");
            boolean primeraCondicion = true;

            if (filtros.containsKey("pais")) {
                if (!primeraCondicion) sb.append(" AND ");
                sb.append("pais ILIKE ?");
                primeraCondicion = false;
            }
            if (filtros.containsKey("departamento")) {
                if (!primeraCondicion) sb.append(" AND ");
                sb.append("departamento ILIKE ?");
                primeraCondicion = false;
            }
            if (filtros.containsKey("municipio")) {
                if (!primeraCondicion) sb.append(" AND ");
                sb.append("municipio ILIKE ?");
                primeraCondicion = false;
            }
            if (filtros.containsKey("ubicacion")) {
                if (!primeraCondicion) sb.append(" AND ");
                sb.append("ubicacion ILIKE ?");
                primeraCondicion = false;
            }
            if (filtros.containsKey("tipo")) {
                if (!primeraCondicion) sb.append(" AND ");
                sb.append("tipo_propiedad ILIKE ?");
                primeraCondicion = false;
            }
            if (filtros.containsKey("cuartos")) {
                if (!primeraCondicion) sb.append(" AND ");
                sb.append("cuartos = ?");
                primeraCondicion = false;
            }
            if (filtros.containsKey("rentaMin") && filtros.containsKey("rentaMax")) {
                if (!primeraCondicion) sb.append(" AND ");
                sb.append("renta BETWEEN ? AND ?");
                primeraCondicion = false;
            }
        }

        sb.append(" ORDER BY id;");

        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sb.toString())) {

            // Index para setear parámetros
            int idx = 1;
            if (filtros.containsKey("pais")) {
                ps.setString(idx++, "%" + filtros.get("pais") + "%");
            }
            if (filtros.containsKey("departamento")) {
                ps.setString(idx++, "%" + filtros.get("departamento") + "%");
            }
            if (filtros.containsKey("municipio")) {
                ps.setString(idx++, "%" + filtros.get("municipio") + "%");
            }
            if (filtros.containsKey("ubicacion")) {
                ps.setString(idx++, "%" + filtros.get("ubicacion") + "%");
            }
            if (filtros.containsKey("tipo")) {
                ps.setString(idx++, "%" + filtros.get("tipo") + "%");
            }
            if (filtros.containsKey("cuartos")) {
                ps.setInt(idx++, (Integer) filtros.get("cuartos"));
            }
            if (filtros.containsKey("rentaMin") && filtros.containsKey("rentaMax")) {
                ps.setDouble(idx++, (Double) filtros.get("rentaMin"));
                ps.setDouble(idx++, (Double) filtros.get("rentaMax"));
            }

            ResultSet rs = ps.executeQuery();
            List<Propiedad> lista = new ArrayList<>();
            while (rs.next()) {
                Propiedad p = new Propiedad(
                        rs.getInt("id"),
                        rs.getString("tipo_propiedad"),
                        rs.getString("direccion"),
                        rs.getString("pais"),
                        rs.getString("departamento"),
                        rs.getString("municipio"),
                        rs.getString("ubicacion"),
                        rs.getInt("cuartos"),
                        rs.getDouble("renta"),
                        rs.getString("estado"),
                        rs.getInt("dueno_id")
                );
                lista.add(p);
            }
            return lista;
        }
    }
}
