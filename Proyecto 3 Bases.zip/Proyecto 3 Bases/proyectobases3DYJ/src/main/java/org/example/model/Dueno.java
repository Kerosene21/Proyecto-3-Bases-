package org.example.model;

public class Dueno extends Usuario {
    public Dueno() { }

    public Dueno(int id, String nombreUsuario, String contrasena,
                 String nombre, String apellido, String correo,
                 String tipoCuenta) {
        super(id, nombreUsuario, contrasena, nombre, apellido, correo, tipoCuenta);
    }
}

