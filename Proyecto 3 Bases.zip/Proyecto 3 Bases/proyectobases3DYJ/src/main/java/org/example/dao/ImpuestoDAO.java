package org.example.dao;

import org.example.model.Impuesto;
import org.example.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ImpuestoDAO {
    private Connection conn;

    public ImpuestoDAO() throws SQLException {
        this.conn = DBConnection.getInstance();
    }

    /**
     * Obtiene todos los impuestos vigentes (para cálculo en RentaService).
     */
    public List<Impuesto> obtenerImpuestosVigentes() throws SQLException {
        String sql = "SELECT * FROM impuesto";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            List<Impuesto> lista = new ArrayList<>();
            while (rs.next()) {
                Impuesto i = new Impuesto();
                i.setId(rs.getInt("id"));
                i.setTipoImpuesto(rs.getString("tipo_impuesto"));
                i.setPorcentaje(rs.getDouble("porcentaje"));
                lista.add(i);
            }
            return lista;
        }
    }

    /**
     * Inserta un impuesto asociado a una renta:
     * Por ejemplo, si quieres grabar a nivel de detalle cada impuesto aplicado.
     */
    public void insertarImpuestoRenta(int rentaId, int impuestoId) throws SQLException {
        String sql = "INSERT INTO impuesto_renta (impuesto_id, renta_id) VALUES (?, ?)";
        // Nota: Debes tener la tabla impuesto_renta que relacione impuesto y renta
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, impuestoId);
            ps.setInt(2, rentaId);
            ps.executeUpdate();
        }
    }

    // Si necesitas obtener impuestos por renta:
    public List<Impuesto> obtenerImpuestosPorRenta(int rentaId) throws SQLException {
        String sql = "SELECT i.id, i.tipo_impuesto, i.porcentaje " +
                "FROM impuesto i " +
                "JOIN impuesto_renta ir ON i.id = ir.impuesto_id " +
                "WHERE ir.renta_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Impuesto> lista = new ArrayList<>();
                while (rs.next()) {
                    Impuesto i = new Impuesto();
                    i.setId(rs.getInt("id"));
                    i.setTipoImpuesto(rs.getString("tipo_impuesto"));
                    i.setPorcentaje(rs.getDouble("porcentaje"));
                    lista.add(i);
                }
                return lista;
            }
        }
    }
}
