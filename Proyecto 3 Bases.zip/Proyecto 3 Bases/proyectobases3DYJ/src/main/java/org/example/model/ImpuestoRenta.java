package org.example.model;

/**
 * ImpuestoRenta: representa la tabla impuesto_renta.
 */
public class ImpuestoRenta {
    private int id;
    private int impuestoId;     // FK → impuesto(id)
    private int rentaId;        // FK → renta(id)

    public ImpuestoRenta() { }

    public ImpuestoRenta(int id, int impuestoId, int rentaId) {
        this.id = id;
        this.impuestoId = impuestoId;
        this.rentaId = rentaId;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getImpuestoId() { return impuestoId; }
    public void setImpuestoId(int impuestoId) { this.impuestoId = impuestoId; }

    public int getRentaId() { return rentaId; }
    public void setRentaId(int rentaId) { this.rentaId = rentaId; }
}
