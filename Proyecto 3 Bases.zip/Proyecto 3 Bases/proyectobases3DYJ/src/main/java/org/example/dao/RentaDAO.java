package org.example.dao;

import org.example.model.Inquilino;
import org.example.model.Renta;
import org.example.util.DBConnection;

import java.sql.*;
import java.util.List;

/**
 * RentaDAO: operaciones CRUD sobre la tabla renta, y sobre inquilino, comision_renta, impuesto_renta, pago.
 */
public class RentaDAO {

    /**
     * Inserta la fila principal en 'renta' y devuelve el id generado.
     */
    public int insertarRenta(Renta r) throws SQLException {
        String sql = """
                INSERT INTO renta
                  (cliente_id, dueno_id, propiedad_id, fecha, vei, vtr, ti, vtp, estado_renta)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                RETURNING id;
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, r.getClienteId());
            ps.setInt(2, r.getDuenoId());
            ps.setInt(3, r.getPropiedadId());
            ps.setDate(4, r.getFecha());
            ps.setDouble(5, r.getVei());
            ps.setDouble(6, r.getVtr());
            ps.setDouble(7, r.getTi());
            ps.setDouble(8, r.getVtp());
            ps.setString(9, r.getEstadoRenta());

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                throw new SQLException("No se pudo insertar Renta.");
            }
        }
    }

    /**
     * Inserta uno o varios Inquilinos asociados a una renta.
     */
    public void insertarInquilinos(List<Inquilino> inquilinos, int rentaId) throws SQLException {
        String sql = """
                INSERT INTO inquilino (renta_id, identificacion, nombre)
                VALUES (?, ?, ?);
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (Inquilino i : inquilinos) {
                ps.setInt(1, rentaId);
                ps.setString(2, i.getIdentificacion());
                ps.setString(3, i.getNombre());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    /**
     * Inserta filas en comision_renta según los servicios seleccionados.
     * El mapa 'servicios' tiene key = idComision, value = numInquilinos.
     */
    public void insertarComisionRenta(int rentaId, java.util.Map<Integer, Integer> servicios) throws SQLException {
        if (servicios.isEmpty()) return;
        String sql = """
                INSERT INTO comision_renta (comision_id, renta_id, num_inquilinos)
                VALUES (?, ?, ?);
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (var entry : servicios.entrySet()) {
                ps.setInt(1, entry.getKey());        // idComision
                ps.setInt(2, rentaId);
                ps.setInt(3, entry.getValue());      // numInquilinos
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    /**
     * Inserta filas en impuesto_renta según la lista de IDs de impuesto.
     */
    public void insertarImpuestoRenta(int rentaId, List<Integer> impuestos) throws SQLException {
        if (impuestos.isEmpty()) return;
        String sql = """
                INSERT INTO impuesto_renta (impuesto_id, renta_id)
                VALUES (?, ?);
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int impId : impuestos) {
                ps.setInt(1, impId);
                ps.setInt(2, rentaId);
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    /**
     * Inserta un pago asociado a una renta.
     */
    public void insertarPago(int rentaId, String tipoPago, double valor, String detalles) throws SQLException {
        String sql = """
                INSERT INTO pago (renta_id, tipo_pago, valor, detalles)
                VALUES (?, ?, ?, ?);
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rentaId);
            ps.setString(2, tipoPago);
            ps.setDouble(3, valor);
            ps.setString(4, detalles);
            ps.executeUpdate();
        }
    }

    /**
     * Comprueba si un cliente ya tiene una renta pendiente (por ejemplo, estado_renta = "Pendiente").
     * Devolverá true si existe por lo menos una renta con ese estado.
     */
    public boolean existeRentaPendiente(int clienteId) throws SQLException {
        String sql = """
                SELECT COUNT(*) 
                FROM renta 
                WHERE cliente_id = ? AND estado_renta = 'Pendiente';
                """;
        try (Connection conn = DBConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, clienteId);
            ResultSet rs = ps.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        }
    }
}
